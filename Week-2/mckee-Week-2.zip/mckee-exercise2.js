/*
============================================
; Title:  mckee-exercise2.js
; Author: Shay McKee
; Date:  06/05/20222
; Description: Displays message to the console window
;===========================================
*/

/**
============================================
; Title:  JavaScript Where To
; Author: w3schools.com
; Date:  06/05/2022
; Modified By: Shay McKee
; Description: Calling statement by using document.getElementById
;===========================================
 */

 /**
============================================
; Title:  JavaScript Popup Boxes
; Author: w3schools.com
; Date:  06/05/2022
; Modified By: Shay McKee
; Description: Function for pop up box when pressing button
;===========================================
 */


/**
 *script binding the world statement to innerHTML of txtMyWorld
 */

 document.getElementById("txtMyWorld").innerHTML = "You are now in McKee's world";

 /**
  * function for button class item and creating alert window for the class I am in
  */
 
 function myFunction() {
     alert("WEB 231 - Enterprise JavaScript I");
 }